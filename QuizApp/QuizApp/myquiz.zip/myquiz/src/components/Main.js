import React from 'react'
import { Link } from 'react-router-dom'

const Main = () => {
  return (
    <>
    <div>
    <Link className='btn' to={'quiz'}>Pro Quizz</Link>
      
    </div>
    </>
  )
}

export default Main
