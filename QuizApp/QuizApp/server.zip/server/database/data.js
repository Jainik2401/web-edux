export default [
    {
        id: 1,
        language:"javascript",
        question : "Javascript is an _______ language",
        options : [
            'Object-Oriented',
            'Object-Based',
            'Procedural',
        ]
    },
    {
        id: 2,
        language:"javascript",
        question : "Following methods can be used to display data in some form using Javascript",
        options : [
            'document.write()',
            'console.log()',
            'window.alert()',
        ]
    },
    {
        id: 3,
        language:"javascript",
        question : "When an operator value is NULL, the typeof returned by the unary operator is:",
        options : [
            'Boolean',
            'Undefined',
            'Object',
        ]
    },
    {
        id: 4,
        language:"javascript",
        question : "What does the toString() method return?",
        options : [
            'Return Object',
            'Return String',
            'Return Integer'
        ]
    },
    {
        id: 5,
        language:"javascript",
        question : "Which function is used to serialize an object into a JSON string?",
        options : [
            'stringify()',
            'parse()',
            'convert()',
        ]
    },
    {
        id: 6,
        language:"css",
        question : "The full form of CSS is:",
        options : [
            'Cascading Style Sheets',
            'Cascading Syntax Sheets',
            'Color and Style Sheets'
        ]
    },
    {
        id: 7,
        language:"css",
        question : "Which of the following CSS selectors are used to specify a group of elements?",
        options : [
            'tag',
            'id',
            'class'
        ]
    },
    {
        id: 8,
        language:"css",
        question : " Which of the following CSS framework is used to create a responsive design?",
        options : [
            'django',
            'bootstrap',
            'rails'
        ]
    },
    {
        id: 9,
        language:"css",
        question : "Which of the following type of HTML tag is used to define an internal style sheet?",
        options : [
            '<script>',
            '<style>',
            '<link>'
        ]
    },
    {
        id: 10,
        language:"css",
        question : "Which of the following CSS property is used to make the text bold?",
        options : [
            'font-weight: bold',
            'font-style: bold',
            'text-decoration: bold'
        ]
    },
    {
        id: 11,
        language:"css",
        question : "Which of the following are the CSS Extension Prefixes for Webkit?",
        options : [
            '-web',
            ' -o-',
            '-webkit'
        ]
    },
    {
        id: 12,
        language:"css",
        question : "Which of the following is the correct way to apply CSS Styles?",
        options : [
            'in an external CSS file',
            'inside an HTML element',
            'all of the mentioned '
        ]
    },
    {
        id: 13,
        language:"html",
        question : " HTML stands for __________",
        options : [
            'HyperText Markup Language',
            'HyperText Marking Language',
            'HyperText Machine Language '
        ]
    },
    {
        id: 14,
        language:"html",
        question : "Which of the following is used to read an HTML page and render it?",
        options : [
            'Web server',
            'Web network',
            'Web browser'
        ]
    },
    {
        id: 15,
        language:"html",
        question : "In which part of the HTML metadata is contained",
        options : [
            'head tag',
            'title tag',
            'body tag'
        ]
    },


];

export const answers = [0, 1, 2, 1, 0, 0, 2, 1, 1, 0, 2, 2, 0, 2, 0];